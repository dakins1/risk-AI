package net.yura.domination.guishared;

/**
 * @author Yura Mamyrin
 */
public interface MapPanel {

    public int getCountryNumber(int x, int y);
    public void repaint();

    public void setHighLight(int i);
    public int getHighLight();

    public void setC1(int i);
    public int getC1();

    public void setC2(int i);
    public int getC2();

    public int getMapWidth();
    public int getMapHeight();
}
